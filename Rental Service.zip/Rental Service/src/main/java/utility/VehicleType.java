package utility;

public enum VehicleType {
    BUS,
    CAR,
    BIKE,
    VAN;
}
